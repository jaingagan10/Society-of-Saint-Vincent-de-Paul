﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace St_Vincent_De_Paul_Society
{
    public partial class UploadForm : Form
    {
        // field variables
        string productName;
        string productDescription;
        decimal productPrice = 0m;
        decimal salePrice = 0m;
        string productType;
        string productLocation;
        string productSize;
        List<string> imageList = new List<string>();
        int flag = 0;               // Added by Shefali
        int item_id;               //Added by Shefali
        string modifyProductName;  //Added by Shefali

        //string in_stock_date= DateTime.Now.ToString("yyyy-MM-dd");


        public UploadForm()
        {
            InitializeComponent();
			FillComboBox();
        }

        // method to automatically fill combo boxes (product category and product location) from database 
        // Code added for Database by Shefali- Start
        void FillComboBox()
        {
            try
            {
                //select Concat(c.category_name, ' ' ,s.sub_category_name) as 'Categories' from category c, sub_category s where c.CATEGORY_ID = s.CATEGORY_ID and c.CATEGORY_NAME not in ('Books', 'Others')
                string connectionString_dataload = "datasource=localhost;port=3308;username=root;password=";
                string dataLoad_sql = "select Concat(c.category_name, ' ' ,s.sub_category_name) as 'Categories'  from test_db.category c, test_db.sub_category s where c.CATEGORY_ID=s.CATEGORY_ID;";
                MySqlConnection connection = new MySqlConnection(connectionString_dataload);
                MySqlCommand data_command = new MySqlCommand(dataLoad_sql, connection);
                connection.Open();
                MySqlDataReader dataload;
                dataload = data_command.ExecuteReader();            
               
                while (dataload.Read())
                {

                    string categories = dataload.GetString(0);
                    ProductTypeComboBox.Items.Add(categories);
                }
               // ProductTypeComboBox.Items.Add("Books");
                //ProductTypeComboBox.Items.Add("OTHER");
                connection.Close();

               // SELECT shop_name FROM test_db.shop;
                string connectionString_dataload1 = "datasource=localhost;port=3308;username=root;password=";
                string dataLoad_sql1 = "SELECT shop_name FROM test_db.shop;";
                MySqlConnection connection1 = new MySqlConnection(connectionString_dataload1);
                MySqlCommand data_command1 = new MySqlCommand(dataLoad_sql1, connection1);
                connection1.Open();
                MySqlDataReader dataload1;
                dataload1 = data_command1.ExecuteReader();

                while (dataload1.Read())
                {

                    string shops = dataload1.GetString(0);
                    ProductLocationComboBox.Items.Add(shops);
                }
                connection1.Close();
            }

            catch (Exception Ex)
            {
                MessageBox.Show("There is a problem with data Load", "Error occured", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Console.WriteLine(Ex);
            }
        }
        // Code added for Database by Shefali- End

        // ----------------------------------------------------------------------------------------------------

        //private string productNameInput;
        private int productCategoryModify = -1;
        private int productLocationModify = -1; 
		private string selectedProductDetails;     //Added by Shefali
        private Boolean isModifyOrDelete = false;
        private Boolean isUpload = false;
        private string selectedProductName;      //Added by Shefali

        public int productCategoryModifySet {
            set
            {
                productCategoryModify = value;
            }
        }

        public Boolean isModifyOrDeleteSet
        {
            set
            {
                isModifyOrDelete = value;
            }
        }

        public Boolean isUploadSet
        {
            set
            {
                isUpload = value;
            }
        }

        public int productLocationLocationSet
        {
            set
            {
                productLocationModify = value;
            }
        }

        //Added by Shefali
		public string selectedProduct
        {
            set
            {
                selectedProductDetails = value;
            }
        }
        //Added by Shefali
        public string selectedProduct_Name
        {
            set
            {
                selectedProductName = value;
            }
        }
        // -----------------------------------------------------------------------------------------------------

        private void UploadForm_Load(object sender, EventArgs e)
        {
            //this.Size = new Size(1206, 895);

            if (productLocationModify != -1 && productCategoryModify != -1)
            {
                ProductTypeComboBox.SelectedIndex = productCategoryModify;
                ProductLocationComboBox.SelectedIndex = productLocationModify;
                ModifyUploadPageButton.Visible = true;
                UploadButton.Visible = false;
                if (imageList.Count == 0)
                {
                    AddPhotosButton.Visible = true;
                    AddMorePicturesButton.Visible = false;
                }
                else
                {
                    AddPhotosButton.Visible = false;
                    AddMorePicturesButton.Visible = true;
                }

                if (selectedProductDetails != "")
                {
                    try
                    {
                        if (selectedProductDetails.Length > 1)
                        {
                            item_id = int.Parse(selectedProductDetails.Substring(0, 2));
                        }
                        else
                        {
                            item_id = int.Parse(selectedProductDetails.Substring(0, 1));
                        }

                        // Code added for Database by Shefali- Start
                        string connectionString_dataload3 = "datasource=localhost;port=3308;username=root;password=";
                        string dataLoad_sql3 = "select  ITEM_NAME, ITEM_DESCRIPTION, PRIZE,SALE, SIZE from test_db.inventory where item_id = '" + item_id + "' ;";
                        MySqlConnection connection3 = new MySqlConnection(connectionString_dataload3);
                        MySqlCommand data_command3 = new MySqlCommand(dataLoad_sql3, connection3);
                        connection3.Open();
                        MySqlDataReader dataload3;
                        dataload3 = data_command3.ExecuteReader();
                        dataload3.Read();
                        modifyProductName = dataload3.GetString(0);
                        ProductNameTextBox.Text = dataload3.GetString(0);
                        ProductDescriptionRichTextBox.Text = dataload3.GetString(1);
                        ProductPriceTextBox.Text = dataload3.GetString(2);
                      
                        if(dataload3.GetValue(dataload3.GetOrdinal("SALE")) == DBNull.Value) //Added by Gagan
                        {
                            SalePriceTextBox.Text = "0";
                        }
                        else
                        {
                            decimal SalePriceText = dataload3.GetDecimal(3);
                            SalePriceTextBox.Text = SalePriceText.ToString();
                        }
                        
                        ProductSizeRichTextBox.Text = dataload3.GetString(4);
                        dataload3.Close();
                        connection3.Close();
                        string connectionString_dataload4 = "datasource=localhost;port=3308;username=root;password=";
                        string dataLoad_sql4 = "select id from test_db.wp_posts where post_title = '" + selectedProductName + "' ;";
                        MySqlConnection connection4 = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand cmd = new MySqlCommand(dataLoad_sql4, connection4);
                        connection4.Open();
                        MySqlDataReader dataload5;
                        dataload5 = cmd.ExecuteReader();
                        dataload5.Read();
                        int wp_item_id = dataload5.GetInt32(0);
                        // MessageBox.Show(wp_item_id.ToString());
                        connection4.Close();

                        string connectionString_dataload5 = "datasource=localhost;port=3308;username=root;password=";
                        string dataLoad_sql5 = "select post_name from test_db.wp_posts where post_parent = '" + wp_item_id + "' ;";
                        MySqlConnection connection5 = new MySqlConnection(connectionString_dataload5);
                        MySqlCommand cmd1 = new MySqlCommand(dataLoad_sql5, connection5);
                        connection5.Open();
                        MySqlDataReader dataload6;
                        dataload6 = cmd1.ExecuteReader();
                        while (dataload6.Read())
                        {

                            // ".jpg" Added by Gagan
                            String image_list = dataload6["post_name"].ToString();

                            ImageListBox.Visible = true;

                            //Added by Gagan
                            imageList.Add(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + image_list + ".jpg");
                           // MessageBox.Show(image_list);
                            ImageListBox.Items.Add(image_list);

                        }
                        connection5.Close();
                        string connectionString_dataload6 = "datasource=localhost;port=3308;username=root;password=";
                        string dataLoad_sql6 = "select meta_value from test_db.wp_postmeta where post_id = '" + wp_item_id + "' and meta_key = '_thumbnail_id' ;";
                        MySqlConnection connection6 = new MySqlConnection(connectionString_dataload6);
                        MySqlCommand cmd2 = new MySqlCommand(dataLoad_sql6, connection6);
                        connection6.Open();
                        MySqlDataReader dataload7;
                        dataload7 = cmd2.ExecuteReader();
                        //dataload7.Read();
                        if (dataload7.Read())
                        {

                            int image_id = dataload7.GetInt32(0);
                        }
                        //int image_id = dataload7.GetInt32(0);
                        //MessageBox.Show(image_id.ToString());
                        connection6.Close();

                        string connectionString_dataload7 = "datasource=localhost;port=3308;username=root;password=";
                        string dataLoad_sql7 = "select post_name from test_db.wp_posts where post_parent = '" + wp_item_id + "' ;";
                        MySqlConnection connection7 = new MySqlConnection(connectionString_dataload7);
                        MySqlCommand cmd3 = new MySqlCommand(dataLoad_sql7, connection7);
                        connection7.Open();
                        MySqlDataReader dataload8;
                        dataload8 = cmd3.ExecuteReader();
                        String image_name = "";
                        if (dataload8.Read())
                        {
                            image_name = dataload8["post_name"].ToString();
                        }
                        //MessageBox.Show(image_name);
                        ImagePictureBox.Image = Image.FromFile(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + image_name + ".jpg");
                       // ImagePictureBox.Image = Image.FromFile(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + image_name);
                        connection7.Close();

                        // Code added by Gagan - Start
                        if(imageList.Count > 1)
                        {
                            DeletePictureButton.Visible = true;
                            ScrollUpPictureBox.Visible = true;
                            ScrollDownPictureBox.Visible = true;
                        }else if(imageList.Count == 1)
                        {
                            DeletePictureButton.Visible = true;
                        }
                        // Code added by Gagan - End


                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show("There some problem with database." +Ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                else
                {
                    ModifyUploadPageButton.Visible = false;
                    UploadButton.Visible = true;
                }


            }
        }



        private void LogOutButton_Click(object sender, EventArgs e)
        {
            DialogResult resultLogout = MessageBox.Show("Do you wish to Log out??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (DialogResult.Yes == resultLogout)
            {
                  this.Hide();

                //Declaring a variable for LoginForm
                   LogInForm f1 = new LogInForm();

                //Showing WelcomeForm
                 f1.ShowDialog();

            }

            else
            {


            }

        }

        private void UploadButton_Click(object sender, EventArgs e)
        {


            // check if product name is entered (mandatory field)
            if (ProductNameTextBox.Text == "" || ProductNameTextBox.Text == "What are you selling?")
            {
                MessageBox.Show("Please Enter a valid Product name", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                // save product name
                productName = ProductNameTextBox.Text;

                // check if product description is entered (mandatory field)
                if (ProductDescriptionRichTextBox.Text == "" || ProductDescriptionRichTextBox.Text == "Describe what you are selling")
                {
                    MessageBox.Show("Please Enter valid Product description", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {
                    productDescription = ProductDescriptionRichTextBox.Text;

                    // product price is mandatory, sale price is not
                    if (ProductPriceTextBox.Text == "Product Price" || ProductPriceTextBox.Text == "")
                    {
                        MessageBox.Show("Please enter the price of the product.", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Error);



                    }
                    else
                    {

                        if (decimal.TryParse(ProductPriceTextBox.Text, out productPrice))
                        {
                            if (!SalePriceTextBox.Text.Contains("Sale Price") || SalePriceTextBox.Text.Length  == 0)
                            {
                                if (!decimal.TryParse(SalePriceTextBox.Text, out salePrice))
                                {
                                    MessageBox.Show("Please Enter valid Sale Price", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                                }
                                else
                                {
                                    decimal.TryParse(SalePriceTextBox.Text, out salePrice);
                                }
                            }

                            if (ProductTypeComboBox.SelectedIndex < 0)
                            {
                                MessageBox.Show("Please select a product type", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }

                            else
                            {
                                productType = ProductTypeComboBox.Text;

                                if (ProductLocationComboBox.SelectedIndex < 0)

                                {
                                    MessageBox.Show("Please select a location", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                                }
                                else
                                {
                                    productLocation = ProductLocationComboBox.Text;


                                    if (ImagePictureBox.ImageLocation is null)
                                    {
                                        MessageBox.Show("Please Upload at least 1 image to continue.", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                    else
                                    {


                                        if ((ProductTypeComboBox.SelectedItem.ToString() == "Clothing Womens" || ProductTypeComboBox.SelectedItem.ToString() == "Clothing Mens" || ProductTypeComboBox.SelectedItem.ToString() == "Clothing Kids" || ProductTypeComboBox.SelectedItem.ToString() == "Clothing Shoes") && (ProductSizeRichTextBox.Text == "if applicable" || ProductSizeRichTextBox.Text == ""))
                                        {
                                            MessageBox.Show("Please enter the size", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        }

                                        else
                                        {
                                            // picture box
                                            try
                                            {
                                                byte[] img = new byte[ImageListBox.Items.Count];
                                                List<string> myimages = new List<string>(); //Added by Shefali
                                                for (int i = 0; i < imageList.Count; i++)
                                                {
                                                    MemoryStream ms = new MemoryStream();
                                                    img = File.ReadAllBytes(imageList[i].ToString());
                                                    //Adding by Shefali to get Image Name
                                                    string myimage = (ImageListBox.Items[i].ToString()).Replace("- Title Image", "");
                                                    myimages.Add(myimage);
                                                }


                                                /*       DialogResult uploadConfirmation = MessageBox.Show("Are you sure you want to upload the new item ?", "Confirm Upload", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                                       if (uploadConfirmation == DialogResult.Yes)
                                                       {


                                                       } */


                                                if (ProductSizeRichTextBox.Text != "" && ProductSizeRichTextBox.Text != "if applicable")
                                                {
                                                    productSize = ProductSizeRichTextBox.Text;
                                                }

                                                if (ProductSizeRichTextBox.Text == "if applicable")
                                                {
                                                    productSize = "no size";

                                                }

                                                // Dialog result Code added by Gagan - Start
                                                DialogResult uploadConfirmation = MessageBox.Show("Are you sure you want to upload the Item ?", "Confirm Upload", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                               
                                                if (uploadConfirmation == DialogResult.Yes)
                                                {
                                                    //Code added by Shefali- Start  Hobbies OTHER
                                                    string[] categories = productType.Split();                                                   
                                                    //string trimmed_productType = productType.Replace("Collectables ", "").Replace("Accessories ", "").Replace("Living ", "").Replace("Clothing ", "").Replace("Hobbies ", "").Replace("Expensive ", "");
                                                    string trimmed_productLocation = productLocation.Replace("Vincent's ", "").Replace(" Road", "");
                                                    string in_stock_date = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
                                                    string connectionString = "datasource=localhost;port=3308;username=root;password=;character set = utf8";
                                                    int category_id = 0;
                                                    //MessageBox.Show("book1");
                                                    string str1 = categories[0];
                                                    string str2 = categories[1];

                                                        
                                                        String sql0 = "SELECT CATEGORY_ID FROM test_db.CATEGORY WHERE CATEGORY_NAME LIKE '%" + str1 + "%';";
                                                        MySqlConnection conn0 = new MySqlConnection(connectionString);
                                                        MySqlCommand command0 = new MySqlCommand(sql0, conn0);
                                                        conn0.Open();
                                                        MySqlDataReader myreader0;
                                                        myreader0 = command0.ExecuteReader();
                                                        myreader0.Read();
                                                        category_id = myreader0.GetInt32(0);                                                        
                                                        myreader0.Close();
                                                        conn0.Close();
                                                    
                                                    
                                                    MySqlDataReader myreader, mydata, mydata1, mydata2;
                                                    int wp_category_id = 0;
                                                    if (str2 == "OTHER")
                                                    {
                                                        string sql2 = "SELECT term_id FROM test_db.wp_terms WHERE name LIKE '" + str2 + "' and slug like '%"+ str1 + "%';";
                                                        MySqlConnection conn2 = new MySqlConnection(connectionString);
                                                        MySqlCommand command2 = new MySqlCommand(sql2, conn2);
                                                        conn2.Open();
                                                        mydata1 = command2.ExecuteReader();
                                                        mydata1.Read();
                                                        wp_category_id = mydata1.GetInt32(0);
                                                        mydata1.Close();
                                                        conn2.Close();
                                                    }
                                                    else
                                                    {
                                                        string sql2 = "SELECT term_id FROM test_db.wp_terms WHERE name LIKE '" + str2 + "' and term_id between '58' and '80';";
                                                        MySqlConnection conn2 = new MySqlConnection(connectionString);
                                                        MySqlCommand command2 = new MySqlCommand(sql2, conn2);
                                                        conn2.Open();
                                                        mydata1 = command2.ExecuteReader();
                                                        mydata1.Read();
                                                        wp_category_id = mydata1.GetInt32(0);
                                                        mydata1.Close();
                                                        conn2.Close();
                                                    }
                                                    
                                                    string sql = "SELECT SUB_CATEGORY_ID FROM test_db.SUB_CATEGORY WHERE SUB_CATEGORY_NAME LIKE '%" + str2 + "%' and CATEGORY_ID = '"+ category_id +"';";
                                                    string sql1 = "SELECT SHOP_ID FROM test_db.SHOP WHERE SHOP_NAME LIKE '%" + trimmed_productLocation + "%';";
                                                    string sql3 = "SELECT id FROM test_db.wp_users WHERE user_nicename LIKE '%" + trimmed_productLocation + "%';";

                                                    //Code for database connection for select statements.                                                   
                                                    MySqlConnection conn = new MySqlConnection(connectionString);
                                                    MySqlConnection conn1 = new MySqlConnection(connectionString);                                                    
                                                    MySqlConnection conn3 = new MySqlConnection(connectionString);                                                    
                                                    MySqlCommand command = new MySqlCommand(sql, conn);
                                                    MySqlCommand command1 = new MySqlCommand(sql1, conn1);                                                    
                                                    MySqlCommand command3 = new MySqlCommand(sql3, conn3);                                                    
                                                    conn.Open();
                                                    conn1.Open();                                                    
                                                    conn3.Open();                                                    
                                                    myreader = command.ExecuteReader();
                                                    mydata = command1.ExecuteReader();                                                    
                                                    mydata2 = command3.ExecuteReader();
                                                    myreader.Read();
                                                    mydata.Read();                                                    
                                                    mydata2.Read();
                                                    int db_category_id = myreader.GetInt32(0);
                                                    int db_shop_id = mydata.GetInt32(0);
                                                                                                       
                                                    int wp_shop_id;
                                                    if (mydata2.Read())
                                                    {
                                                        wp_shop_id = mydata2.GetInt32(0);
                                                    }
                                                    wp_shop_id = mydata2.GetInt32(0);
                                                
                                                    myreader.Close();
                                                    mydata.Close();                                                    
                                                    mydata2.Close();
                                                    conn.Close();
                                                    conn1.Close();                                                    
                                                    conn3.Close();


                                                    string mysql = "INSERT INTO test_db.INVENTORY (ITEM_NAME, ITEM_DESCRIPTION, SUB_CATEGORY_ID,PRIZE, SALE, SIZE, PICTURE, IN_STOCK_DATE,ITEM_STATUS,SHOP_ID,SEASON_ID) VALUES('"
                                                    + productName + "', '" + productDescription + "', '" + db_category_id + "','" + productPrice + "','" + salePrice + "','" + productSize + "', '" + img + "' ,'" + in_stock_date + "', 'In Stock','" + db_shop_id + "', '1');";
                                                    MySqlConnection conn5 = new MySqlConnection(connectionString);
                                                    MySqlCommand command5 = new MySqlCommand(mysql, conn5);
                                                    conn5.Open();
                                                    command5.ExecuteNonQuery();
                                                    conn5.Close();
                                                    string productName1 = productName.Replace(" ", "-");

                                                    //Woocommerce
                                                    string mysql1 = "INSERT INTO test_db.wp_posts (post_author, post_date, post_date_gmt, post_content,post_title, post_excerpt, post_status,comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt,post_content_filtered, post_parent , guid, menu_order, post_type, post_mime_type, comment_count) VALUES('" + wp_shop_id + "', '"
                                                    + in_stock_date + "','" + in_stock_date + "','', '"
                                                    + productName + "','" + productDescription + "','publish', 'closed', 'closed','', '" + productName1 + "','','', '" + in_stock_date + "','" + in_stock_date + "','' , '0', '','0', 'product','', '0') ; ";
                                                    /*string mysql1 = "INSERT INTO test_db.wp_posts(post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status,ping_status,  post_name, post_modified, post_modified_gmt, post_parent, menu_order, post_type, comment_count) VALUES ('" + wp_shop_id + "' , '" + in_stock_date + "', '" + in_stock_date + "', '<span style=\"color: #201f1e; font-family: \'Segoe UI\', \'Segoe UI Web (West European)\', \'Segoe UI\', -apple-system, BlinkMacSystemFont, Roboto, \'Helvetica Neue\', sans-serif; font-size: 15px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">PS4 audiovisual game available for purchase at Vincent\'s, Merchant road</span>' ,'" + productName + "','" + productDescription + "','publish','closed','closed','" + productName + "','" + in_stock_date + "','" + in_stock_date + "','0','0','product','0');";*/
                                                    MySqlConnection conn4 = new MySqlConnection(connectionString);
                                                    MySqlCommand command4 = new MySqlCommand(mysql1, conn4);
                                                    conn4.Open();
                                                    command4.ExecuteNonQuery();
                                                    conn4.Close();
                                                    string mysql2 = "select id from test_db.wp_posts where post_type = 'product' and post_title = '" + productName + "';";
                                                    MySqlConnection conn6 = new MySqlConnection(connectionString);
                                                    MySqlCommand command6 = new MySqlCommand(mysql2, conn6);
                                                    conn6.Open();
                                                    MySqlDataReader myreader1;
                                                    myreader1 = command6.ExecuteReader();
                                                    myreader1.Read();
                                                    int wordpress_item_id = myreader1.GetInt32(0);
                                                    //MessageBox.Show(wordpress_item_id.ToString());
                                                    myreader1.Close();
                                                    conn6.Close();
                                                    if (salePrice != 0)
                                                    {
                                                        string mysql3 = "INSERT INTO test_db.wp_term_relationships VALUES ('" + wordpress_item_id + "','" + wp_category_id + "','0'); INSERT INTO test_db.wp_postmeta(post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_regular_price', '" + productPrice + "'); INSERT INTO test_db.wp_postmeta(post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_price', '" + salePrice + "');  INSERT INTO test_db.wp_postmeta(post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_sale_price', '" + salePrice + "');";
                                                        MySqlConnection conn11 = new MySqlConnection(connectionString);
                                                        MySqlCommand command11 = new MySqlCommand(mysql3, conn11);
                                                        conn11.Open();
                                                        command11.ExecuteNonQuery();
                                                        conn11.Close();
                                                    }
                                                    else
                                                    {
                                                        string mysql3 = "INSERT INTO test_db.wp_term_relationships VALUES ('" + wordpress_item_id + "','" + wp_category_id + "','0'); INSERT INTO test_db.wp_postmeta(post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_regular_price', '" + productPrice + "'); INSERT INTO test_db.wp_postmeta(post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_price', '" + productPrice + "'); ";
                                                        MySqlConnection conn11 = new MySqlConnection(connectionString);
                                                        MySqlCommand command11 = new MySqlCommand(mysql3, conn11);
                                                        conn11.Open();
                                                        command11.ExecuteNonQuery();
                                                        conn11.Close();
                                                    }

                                                    string mysql4 = "update test_db.wp_posts set guid = 'http://localhost/mysite/wordpress/?post_type=product&#038;p=" + wordpress_item_id + "'  where id = '" + wordpress_item_id + "';update test_db.wp_posts set post_content='<span style=\"color: #201f1e; font-family: ''Segoe UI'', ''Segoe UI Web (West European)'', ''Segoe UI'', -apple-system, BlinkMacSystemFont, Roboto, ''Helvetica Neue'', sans-serif; font-size: 15px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">" + productName + " available for purchase at Vincent''s, " + productLocation.Replace("Vincent's ", "") + "</span>' where id = '" + wordpress_item_id + "'; ";
                                                    MySqlConnection conn7 = new MySqlConnection(connectionString);
                                                    MySqlCommand command7 = new MySqlCommand(mysql4, conn7);
                                                    conn7.Open();
                                                    command7.ExecuteNonQuery();
                                                    conn7.Close();

                                                    int count = 1;
                                                    foreach (string image in myimages)
                                                    {
                                                        string imageName = image.Replace(".jpg", "");
                                                        string imageName1 = imageName.Replace(" ", "-");
                                                        string mysql6 = "select id from test_db.wp_posts where post_type = 'attachment' and post_title = '" + imageName + "';";
                                                        MySqlConnection conn9 = new MySqlConnection(connectionString);
                                                        MySqlCommand command9 = new MySqlCommand(mysql6, conn9);
                                                        conn9.Open();
                                                        MySqlDataReader myreader2;
                                                        myreader2 = command9.ExecuteReader();
                                                      
                                                        if (!myreader2.Read())   //for empty
                                                        {
                                                            string mysql5 = "INSERT INTO test_db.wp_posts (post_author, post_date, post_date_gmt, post_content,post_title, post_excerpt, post_status,comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt,post_content_filtered, post_parent , guid, menu_order, post_type, post_mime_type, comment_count) VALUES('" + wp_shop_id + "', '" + in_stock_date + "', '" + in_stock_date + "', '', '" + imageName + "','','inherit', 'open', 'closed','', '" + imageName1 + "','','', '" + in_stock_date + "','" + in_stock_date + "','' , '" + wordpress_item_id + "', 'http://localhost/mysite/wordpress/wp-content/uploads/2020/03/" + imageName1 + ".jpg','0', 'attachment','image/jpeg', '0') ;";
                                                            MySqlConnection conn8 = new MySqlConnection(connectionString);
                                                            MySqlCommand command8 = new MySqlCommand(mysql5, conn8);
                                                            conn8.Open();
                                                            command8.ExecuteNonQuery();
                                                            conn8.Close();

                                                            string mysql8 = "select id from test_db.wp_posts where post_type = 'attachment' and post_title = '" + imageName + "';";
                                                            MySqlConnection conn12 = new MySqlConnection(connectionString);
                                                            MySqlCommand command12 = new MySqlCommand(mysql8, conn12);
                                                            conn12.Open();
                                                            MySqlDataReader myreader3;
                                                            myreader3 = command12.ExecuteReader();
                                                            myreader3.Read();
                                                            int image_id = myreader3.GetInt32(0);
                                                            //MessageBox.Show(image_id.ToString());
                                                            myreader3.Close();
                                                            conn12.Close();
                                                            if (count == 1)
                                                            {
                                                                string mysql7 = "INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "', '_thumbnail_id', '" + image_id + "');INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attached_file','2020/03/" + imageName1 + ".jpg'); INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attachment_metadata','a:5:{s:5:\"width\";i:468;s:6:\"height\";i:801;s:4:\"file\";s:22:\"2020/03/" + imageName1 + ".jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-175x300.jpg\";s:5:\"width\";i:175;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:15:\"Siddhant Kandoi\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1583371749\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');";
                                                                MySqlConnection conn10 = new MySqlConnection(connectionString);
                                                                MySqlCommand command10 = new MySqlCommand(mysql7, conn10);
                                                                conn10.Open();
                                                                command10.ExecuteNonQuery();
                                                                conn10.Close();
                                                                count++;
                                                            }
                                                            else
                                                            {
                                                                string mysql7 = "INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_product_image_gallery','" + image_id + "');INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attached_file','2020/03/" + imageName1 + ".jpg'); INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attachment_metadata','a:5:{s:5:\"width\";i:468;s:6:\"height\";i:801;s:4:\"file\";s:22:\"2020/03/" + imageName1 + ".jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-175x300.jpg\";s:5:\"width\";i:175;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:15:\"Siddhant Kandoi\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1583371749\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');";
                                                                MySqlConnection conn10 = new MySqlConnection(connectionString);
                                                                MySqlCommand command10 = new MySqlCommand(mysql7, conn10);
                                                                conn10.Open();
                                                                command10.ExecuteNonQuery();
                                                                conn10.Close();
                                                            }
                                                            conn9.Close();
                                                        }

                                                    }
                                                    //Code added by Shefali- End

                                                    //wp_post_meta query to be ADDED.
                                                    MessageBox.Show("Item has been successfully added", "Congratulations", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    ProductNameTextBox.Text = "What are you selling?";
                                                    ProductDescriptionRichTextBox.Text = "Describe what you are selling";
                                                    ProductSizeRichTextBox.Text = "if applicable";
                                                    ProductPriceTextBox.Text = "Product Price";
                                                    SalePriceTextBox.Text = "Sale Price";
                                                    ProductTypeComboBox.SelectedIndex = -1;
                                                    ProductLocationComboBox.SelectedIndex = -1;
                                                    ImagePictureBox.Image = null;
                                                    ImageListBox.Visible = false;
                                                    ImagePictureBox.Visible = true;
                                                    ImageLabel.Visible = true;
                                                    imageList.Clear();
                                                    ImageListBox.Items.Clear();
                                                    AddMorePicturesButton.Visible = false;
                                                    ScrollUpPictureBox.Visible = false;
                                                    ScrollDownPictureBox.Visible = false;
                                                    DeletePictureButton.Visible = false;


                                                }
                                            }

                                            catch (Exception Ex)
                                            {
                                                MessageBox.Show("There is a problem with the database connection", "Error occured", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                                Console.WriteLine(Ex);
                                            }


                                        }




                                    }
                                }


                            }



                        }



                    
                        else
                        {
                            MessageBox.Show("Please enter a valid  price of the product.", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }


                        //MessageBox.Show("Please enter the price of the product.", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    

                    
                
                }


            }



         }

            private void BackButton_Click(object sender, EventArgs e)
            {

            DialogResult resultBack = MessageBox.Show("Are you sure you want to go back? Unsaved records will be lost.", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (DialogResult.Yes == resultBack)
            {
                this.Hide();

                if(isModifyOrDelete == true)
                {
                    ModifyScreen f4 = new ModifyScreen();
                    f4.ShowDialog();
                }
                else
                {
                    //Declaring a variable for WelcomeForm
                    WelcomeForm f2 = new WelcomeForm();

                    //Showing WelcomeForm
                    f2.ShowDialog();

                }






            }
        
        }

            private void AddPhotosButton_Click(object sender, EventArgs e)
            {

                string imageLocation = "";
                try
                {
                    OpenFileDialog dialog = new OpenFileDialog();
                    dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png| All Files(*.*)|*.*";

                    if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        flag = 1;
                        imageLocation = dialog.FileName;
                        //Code Added by Shefali - Start
                        String imageName1 = Path.GetFileName(imageLocation);
                        String ImageName = imageName1.Replace(" ", "-");
                        String ImageName1 = ImageName.Replace(".jpg", "");
                        File.Copy(imageLocation, Path.Combine(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\", Path.GetFileName(ImageName)), true);
                        Image image1 = new Bitmap(imageLocation);
                        Bitmap bmp = new Bitmap(image1, 175, 300);
                        Image img = new Bitmap(bmp);
                        img.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-175x300.jpg");

                        Bitmap bmp1 = new Bitmap(image1, 100, 100);
                        Image img1 = new Bitmap(bmp1);
                        img1.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-100x100.jpg");

                        Bitmap bmp2 = new Bitmap(image1, 150, 150);
                        Image img2 = new Bitmap(bmp2);
                        img2.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-150x150.jpg");

                        Bitmap bmp3 = new Bitmap(image1, 265, 331);
                        Image img3 = new Bitmap(bmp3);
                        img3.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-265x331.jpg");
                        //Code Added by Shefali - End
                        ImagePictureBox.ImageLocation = imageLocation;
                        imageList.Add(imageLocation);
                        ImageListBox.Items.Add(Path.GetFileName(imageLocation) +"- Title Image");
                        DeletePictureButton.Visible = true;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("You didn't select a picture. Do you want to proceed without a picture?", "Missing picture", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

                }
            if  (! (ImagePictureBox.ImageLocation is null))
            {
                AddMorePicturesButton.Visible = true;
                ImageLabel.Visible = false;
            }

        }

        
        

        private void ProductDescriptionRichTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddMorePicturesButton_Click(object sender, EventArgs e)
        {
            

            String imageLocation = "";

            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png| All Files(*.*)|*.*";

                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    flag = 1;
                    imageLocation = dialog.FileName;
                    imageList.Add(imageLocation);
                    ImageListBox.Items.Add(Path.GetFileName(imageLocation));
                    //Code Added by Shefali - Start
                    String imageName1 = Path.GetFileName(imageLocation);
                    String ImageName = imageName1.Replace(" ", "-");
                    String ImageName1 = ImageName.Replace(".jpg", "");
                    File.Copy(imageLocation, Path.Combine(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\", Path.GetFileName(ImageName)), true);
                    Image image1 = new Bitmap(imageLocation);
                    Bitmap bmp = new Bitmap(image1, 175, 300);
                    Image img = new Bitmap(bmp);
                    img.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-175x300.jpg");
                    Bitmap bmp1 = new Bitmap(image1, 100, 100);
                    Image img1 = new Bitmap(bmp1);
                    img1.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-100x100.jpg");
                    Bitmap bmp2 = new Bitmap(image1, 150, 150);
                    Image img2 = new Bitmap(bmp2);
                    img2.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-150x150.jpg");
                    Bitmap bmp3 = new Bitmap(image1, 265, 331);
                    Image img3 = new Bitmap(bmp3);
                    img3.Save(@"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\" + ImageName1 + "-265x331.jpg");
                    //Code Added by Shefali - End
                    ImageListBox.Visible = true;
                    //ImagePictureBox.Visible = false;
                    AddMorePicturesButton.Visible = false;
                    AddMorePicturesButton.Visible = true;
                    ImageListBox.SelectedIndex = 0;
                    ScrollDownPictureBox.Visible = true;
                    ScrollUpPictureBox.Visible = true;
                    
                    
                }
            }
            catch (Exception)
            {
                MessageBox.Show("You didn't select a picture. Do you want to proceed without a picture?", "Missing picture", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

            }


            /*
            int count = 1;

            if (count != 5)
            {
                string imageLocation = "";
                try
                {
                    OpenFileDialog dialog = new OpenFileDialog();
                    dialog.Filter = "jpg files(*.jpg)|*.jpg| PNG files(*.png)|*.png| All Files(*.*)|*.*";

                    if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        imageLocation = dialog.FileName;
                       // ImagePictureBox.ImageLocation = imageLocation;

                    }

                    PictureBox picture = new PictureBox
                    {
                        Name = "ImagePictureBox" + count,
                        Size = new Size(93, 104),
                        Location = new Point(ImagePictureBox.Location.X + 104 + (count * 5), ImagePictureBox.Location.Y),
                        ImageLocation = imageLocation,
                    };
                    panel1.Controls.Add(picture);
                }
                catch (Exception)
                {
                    MessageBox.Show("You didn't select a picture. Do you want to proceed without a picture?", "Missing picture", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

                }*/
        }

        private void AddPhotosPictureBox_Click(object sender, EventArgs e)
        {
            AddPhotosButton.PerformClick();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();
            try
            {
                if (ImageListBox.SelectedIndex != -1 || ImageListBox.Visible == false )
                {


                if(imageList.Count == 1)
                {
                     dr =  MessageBox.Show("Are you sure you want to delete the Image " + ImageListBox.Items[0], "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                }
                else if(imageList.Count > 1 && ImageListBox.SelectedIndex != -1)
                {
                    dr =   MessageBox.Show("Are you sure you want to delete the Image " + ImageListBox.SelectedItem, "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                }

                    if (DialogResult.Yes == dr)
                    {

                        if (ImageListBox.SelectedIndex != -1 && imageList.Count != 1)
                        {
                            if (imageList.Count != 0 && imageList.Count > 1)
                            {
                                //Code added by Shefali - Start
                                flag = 1;
                                string imageName = ImageListBox.SelectedItem.ToString();
                                string imageName1 = imageName.Replace(".jpg", "");
                                //string imageName2 = imageName1.Replace(" ", "-");
                                //MessageBox.Show(imageName1);
                                string connectionString = "datasource=localhost;port=3308;username=root;password=";
                                string mysql6 = "select id from test_db.wp_posts where post_type = 'attachment' and post_name = '" + imageName1 + "';";
                                MySqlConnection conn9 = new MySqlConnection(connectionString);
                                MySqlCommand command9 = new MySqlCommand(mysql6, conn9);
                                conn9.Open();
                                MySqlDataReader myreader2;
                                myreader2 = command9.ExecuteReader();                             
                               if (myreader2.Read())  
                               {
                                    int image_id = myreader2.GetInt32(0);
                                    //MessageBox.Show(image_id.ToString());
                                
                                    string mysql5 = "DELETE FROM test_db.wp_posts Where id = '" + image_id + "'; DELETE FROM test_db.wp_postmeta Where meta_value = '" + image_id + "'; DELETE FROM test_db.wp_postmeta Where post_id = '" + image_id + "' ;";
                                    MySqlConnection conn8 = new MySqlConnection(connectionString);
                                    MySqlCommand command8 = new MySqlCommand(mysql5, conn8);
                                    conn8.Open();
                                    command8.ExecuteNonQuery();
                                    conn8.Close();
                               }
                                conn9.Close();
                                //Code added by Shefali - End
                              //  MessageBox.Show("Issue is here.");               //Added by Shefali - getting issue after this code.
                                
                                imageList.RemoveAt(ImageListBox.SelectedIndex);
                                ImageListBox.Items.RemoveAt(ImageListBox.SelectedIndex);
                                ImageListBox.SelectedIndex = 0;

                                if (imageList.Count == 1)
                                {

                                    ImagePictureBox.Visible = true;
                                    ImageListBox.Visible = false;
                                    ScrollUpPictureBox.Visible = false;
                                    ScrollDownPictureBox.Visible = false;
                                   
                                    ImagePictureBox.ImageLocation = imageList[0];
                                    //ImageListBox.SelectedIndex = 0;
                                    ImageListBox.Items[0] = Path.GetFileName(imageList[0]) + "- Title Image";
                                }
                                else
                                {
                                    
                                    ImagePictureBox.Visible = true;
                                    ImageListBox.Visible = true;
                                    ImagePictureBox.ImageLocation = imageList[0];
                                    //ImageListBox.SelectedIndex = 0;
                                    ImageListBox.Items[0] = Path.GetFileName(imageList[0]) + "- Title Image";
                                }
                            }

                        }
                        else if (imageList.Count == 1)
                        {
                         //   MessageBox.Show("Issue is here.");       //Added by Shefali - getting issue after this code.
                            ImagePictureBox.Image = null;
                            imageList.RemoveAt(0);
                            ImageListBox.Items.RemoveAt(0);
                            DeletePictureButton.Visible = false;
                            AddMorePicturesButton.Visible = false;
                            AddPhotosButton.Visible = true;
                            //ImageListBox.SelectedIndex = -1;
                        }
                    }
                    

                }
                else
                {
                    MessageBox.Show("Please select a image from list box to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception Ex)
            {
                MessageBox.Show("Error has Occured while deleting a Picture, Please Contact your adminstrator."+Ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Console.WriteLine("Error has occured while deleting a picture"+Ex);
            }


        }

        private void ModifyUploadPageButton_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < imageList.Count; i++)
            {
               // MessageBox.Show(imageList[i]);
            }
            

			if (ProductNameTextBox.Text == "" || ProductNameTextBox.Text == "What are you selling?")
            {
                MessageBox.Show("Please Enter a valid Product name", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                productName = ProductNameTextBox.Text;

                if (ProductDescriptionRichTextBox.Text == "" || ProductDescriptionRichTextBox.Text == "Describe what you are selling")
                {
                    MessageBox.Show("Please Enter valid Product description", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {
                    productDescription = ProductDescriptionRichTextBox.Text;
                             
                        if (decimal.TryParse(ProductPriceTextBox.Text, out productPrice))
                        {
                    }
                        else
                        { 
                            MessageBox.Show("Price has to be a number, e.g. 19.90", "Wrong data type", MessageBoxButtons.OK, MessageBoxIcon.Error);


                    }
                    if (decimal.TryParse(SalePriceTextBox.Text, out salePrice))
                    {
                    }
                    else
                    {
                        MessageBox.Show("Price has to be a number, e.g. 19.90", "Wrong data type", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }


                    if (ProductTypeComboBox.SelectedIndex < 0)
                        {
                            MessageBox.Show("Please select a product type", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }

                        else
                        {
                            productType = ProductTypeComboBox.SelectedItem.ToString();

                            if (ProductLocationComboBox.SelectedIndex < 0)

                            {
                                MessageBox.Show("Please select a location", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                            }
                            else
                            {
                                productLocation = ProductLocationComboBox.SelectedItem.ToString();

                            if ((ProductTypeComboBox.SelectedItem.ToString() == "Clothing Womens" || ProductTypeComboBox.SelectedItem.ToString() == "Clothing Mens" || ProductTypeComboBox.SelectedItem.ToString() == "Clothing Kids" || ProductTypeComboBox.SelectedItem.ToString() == "Clothing Shoes") && (ProductSizeRichTextBox.Text == "if applicable" || ProductSizeRichTextBox.Text == ""))
                            {

                                    MessageBox.Show("Please enter the size", "Missing input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    // picture box
                                    try
                                    {
                                                                            
                                    if (ProductSizeRichTextBox.Text != "")
                                    {

                                        productSize = ProductSizeRichTextBox.Text;
                                    }

                                    //Code added by Shefali for Modify- Start
                                    string[] categories = productType.Split();
                                    //string trimmed_productType = productType.Replace("Collectables ", "").Replace("Accessories ", "").Replace("Living ", "").Replace("Clothing ", "").Replace("Hobbies ", "").Replace("Expensive ", "");
                                    string trimmed_productLocation = productLocation.Replace("Vincent's ", "").Replace(" Road", "");
                                    string in_stock_date = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
                                    string connectionString = "datasource=localhost;port=3308;username=root;password=;character set = utf8";
                                    int category_id = 0;
                                    //MessageBox.Show("book1");
                                    string str1 = categories[0];
                                    string str2 = categories[1];
                                

                                    String sql0 = "SELECT CATEGORY_ID FROM test_db.CATEGORY WHERE CATEGORY_NAME LIKE '%" + str1 + "%';";
                                    MySqlConnection conn0 = new MySqlConnection(connectionString);
                                    MySqlCommand command0 = new MySqlCommand(sql0, conn0);
                                    conn0.Open();
                                    MySqlDataReader myreader0;
                                    myreader0 = command0.ExecuteReader();
                                    myreader0.Read();
                                    category_id = myreader0.GetInt32(0);
                                    myreader0.Close();
                                    conn0.Close();                                   

                                    MySqlDataReader myreader, mydata, mydata1, mydata2;
                                    int wp_category_id = 0;
                                    if (str2 == "OTHER")
                                    {
                                        string sql2 = "SELECT term_id FROM test_db.wp_terms WHERE name LIKE '" + str2 + "' and slug like '%" + str1 + "%';";
                                        MySqlConnection conn2 = new MySqlConnection(connectionString);
                                        MySqlCommand command2 = new MySqlCommand(sql2, conn2);
                                        conn2.Open();
                                        mydata1 = command2.ExecuteReader();
                                        mydata1.Read();
                                        wp_category_id = mydata1.GetInt32(0);
                                        mydata1.Close();
                                        conn2.Close();
                                    }
                                    else
                                    {
                                        string sql2 = "SELECT term_id FROM test_db.wp_terms WHERE name LIKE '" + str2 + "' and term_id between '58' and '80';";
                                        MySqlConnection conn2 = new MySqlConnection(connectionString);
                                        MySqlCommand command2 = new MySqlCommand(sql2, conn2);
                                        conn2.Open();
                                        mydata1 = command2.ExecuteReader();
                                        mydata1.Read();
                                        wp_category_id = mydata1.GetInt32(0);
                                        mydata1.Close();
                                        conn2.Close();
                                    }

                                    string sql = "SELECT SUB_CATEGORY_ID FROM test_db.SUB_CATEGORY WHERE SUB_CATEGORY_NAME LIKE '%" + str2 + "%' and CATEGORY_ID = '" + category_id + "';";
                                    string sql1 = "SELECT SHOP_ID FROM test_db.SHOP WHERE SHOP_NAME LIKE '%" + trimmed_productLocation + "%';";
                                    string sql3 = "SELECT id FROM test_db.wp_users WHERE user_nicename LIKE '%" + trimmed_productLocation + "%';";

                                    //Code for database connection for select statements.                                                   
                                    MySqlConnection conn = new MySqlConnection(connectionString);
                                    MySqlConnection conn1 = new MySqlConnection(connectionString);
                                    MySqlConnection conn3 = new MySqlConnection(connectionString);
                                    MySqlCommand command = new MySqlCommand(sql, conn);
                                    MySqlCommand command1 = new MySqlCommand(sql1, conn1);
                                    MySqlCommand command3 = new MySqlCommand(sql3, conn3);
                                    conn.Open();
                                    conn1.Open();
                                    conn3.Open();
                                    myreader = command.ExecuteReader();
                                    mydata = command1.ExecuteReader();
                                    mydata2 = command3.ExecuteReader();
                                    myreader.Read();
                                    mydata.Read();
                                    mydata2.Read();
                                    int db_category_id = myreader.GetInt32(0);
                                    int db_shop_id = mydata.GetInt32(0);

                                    int wp_shop_id;
                                    if (mydata2.Read())
                                    {
                                        wp_shop_id = mydata2.GetInt32(0);
                                    }
                                    wp_shop_id = mydata2.GetInt32(0);

                                    myreader.Close();
                                    mydata.Close();
                                    mydata2.Close();
                                    conn.Close();
                                    conn1.Close();
                                    conn3.Close();

                                    //Modify Code
                                    if (ImagePictureBox.Image == null)
                                    { 
										string connectionString_dataload4 = "datasource=localhost;port=3308;username=root;password=";
										string dataLoad_sql4 = "update test_db.inventory set ITEM_NAME='" + ProductNameTextBox.Text + "', ITEM_DESCRIPTION='" + ProductDescriptionRichTextBox.Text + "', PRIZE='" + productPrice + "', SALE='" + salePrice + "' , SIZE ='" + ProductSizeRichTextBox.Text + "' where ITEM_ID = '" + item_id + "';";
										MySqlConnection connection4 = new MySqlConnection(connectionString_dataload4);
										MySqlCommand data_command4 = new MySqlCommand(dataLoad_sql4, connection4);
										connection4.Open();
										data_command4.ExecuteNonQuery();
										connection4.Close();

                                        // MessageBox.Show(modifyProductName);
                                        string sql4 = "select id from test_db.wp_posts where post_type = 'product' and post_title = '" + modifyProductName + "';";
                                        MySqlConnection conn4 = new MySqlConnection(connectionString_dataload4);
                                        MySqlCommand command4 = new MySqlCommand(sql4, conn4);
                                        conn4.Open();
                                        MySqlDataReader myreader2;
                                        myreader2 = command4.ExecuteReader();
                                        myreader2.Read();
                                        int wordpress_item_id = myreader2.GetInt32(0);
                                        // MessageBox.Show(wordpress_item_id.ToString());
                                        myreader2.Close();
                                        conn4.Close();

                                      
                                        string dataLoad_sql5 = "UPDATE test_db.wp_posts set post_title='" + productName + "', post_author= '" + wp_shop_id + "',post_excerpt='" + productDescription + "', post_modified='" + in_stock_date + "', post_modified_gmt='" + in_stock_date + "' WHERE ID = '" + wordpress_item_id + "';  UPDATE test_db.wp_postmeta SET meta_value='" + productPrice + "' WHERE post_id= '" + wordpress_item_id + "' and meta_key='_regular_price'; UPDATE test_db.wp_term_relationships SET term_taxonomy_id = '" + wp_category_id + "'  WHERE object_id = '" + wordpress_item_id + "';";
                                        //string dataLoad_sql5 = "DELETE FROM test_db.wp_term_relationships WHERE object_id= '" + wordpress_item_id + "';DELETE FROM test_db.wp_postmeta WHERE post_id= '" + wordpress_item_id + "'; DELETE FROM test_db.wp_posts WHERE ID = '" + wordpress_item_id + "'; ";
                                        MySqlConnection connection5 = new MySqlConnection(connectionString_dataload4);
                                        MySqlCommand data_command5 = new MySqlCommand(dataLoad_sql5, connection5);
                                        connection5.Open();
                                        data_command5.ExecuteNonQuery();
                                        connection5.Close();

                                        if (salePrice != 0m)
                                        {
                                            string mysql3 = "UPDATE test_db.wp_postmeta SET meta_value = '" + salePrice + "' WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_price'; UPDATE test_db.wp_postmeta SET meta_value = '" + salePrice + "' WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_sale_price'; ";
                                            MySqlConnection conn11 = new MySqlConnection(connectionString);
                                            MySqlCommand command11 = new MySqlCommand(mysql3, conn11);
                                            conn11.Open();
                                            command11.ExecuteNonQuery();
                                            conn11.Close();
                                            //MessageBox.Show(salePrice.ToString());
                                        }
                                        else
                                        {
                                            string mysql3 = "UPDATE test_db.wp_postmeta SET meta_value = '" + productPrice + "' WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_price'; DELETE from test_db.wp_postmeta WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_sale_price';";
                                            MySqlConnection conn11 = new MySqlConnection(connectionString);
                                            MySqlCommand command11 = new MySqlCommand(mysql3, conn11);
                                            conn11.Open();
                                            command11.ExecuteNonQuery();
                                            conn11.Close();
                                            //MessageBox.Show(salePrice.ToString());
                                        }

                                        MessageBox.Show("Records have been modified", "Congratulations", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        this.Hide();

                                        //Declaring a variable for WelcomeForm
                                        WelcomeForm f2 = new WelcomeForm();

                                        //Showing WelcomeForm
                                        f2.ShowDialog();
                                    }
                                    else
                                    {

                                        byte[] img = new byte[ImageListBox.Items.Count];
                                        List<string> myimages = new List<string>();
                                        for (int i = 0; i < imageList.Count; i++)
                                        {
                                            MemoryStream ms = new MemoryStream();
                                            img = File.ReadAllBytes(imageList[i].ToString());
                                            string myimage = (ImageListBox.Items[i].ToString()).Replace("- Title Image", "");
                                            myimages.Add(myimage);
                                        }

                                        string connectionString_dataload4 = "datasource=localhost;port=3308;username=root;password=";
                                        string dataLoad_sql4 = "update test_db.inventory set ITEM_NAME='" + ProductNameTextBox.Text + "', ITEM_DESCRIPTION='" + ProductDescriptionRichTextBox.Text + "', PRIZE='" + productPrice + "', SALE='" + salePrice + "', SIZE ='" + ProductSizeRichTextBox.Text + "', PICTURE = '" +img+ "' where ITEM_ID = '" + item_id + "';";
                                        MySqlConnection connection4 = new MySqlConnection(connectionString_dataload4);
                                        MySqlCommand data_command4 = new MySqlCommand(dataLoad_sql4, connection4);
                                        connection4.Open();
                                        data_command4.ExecuteNonQuery();
                                        connection4.Close();

                                        string sql4 = "select id from test_db.wp_posts where post_type = 'product' and post_title = '" + modifyProductName + "';";
                                        MySqlConnection conn4 = new MySqlConnection(connectionString_dataload4);
                                        MySqlCommand command4 = new MySqlCommand(sql4, conn4);
                                        conn4.Open();
                                        MySqlDataReader myreader2;
                                        myreader2 = command4.ExecuteReader();
                                        myreader2.Read();
                                        int wordpress_item_id = myreader2.GetInt32(0);
                                      //  MessageBox.Show(wordpress_item_id.ToString());
                                        myreader2.Close();
                                        conn4.Close();

                                      
                                        string dataLoad_sql5 = "UPDATE test_db.wp_posts set post_title='" + productName + "', post_author= '" + wp_shop_id + "',post_excerpt='" + productDescription + "', post_modified='" + in_stock_date + "', post_modified_gmt='" + in_stock_date + "' WHERE ID = '" + wordpress_item_id + "';  UPDATE test_db.wp_postmeta SET meta_value='" + productPrice + "' WHERE post_id= '" + wordpress_item_id + "' and meta_key='_regular_price'; UPDATE test_db.wp_term_relationships SET term_taxonomy_id = '" + wp_category_id + "'  WHERE object_id = '" + wordpress_item_id + "';";
                                        //string dataLoad_sql5 = "DELETE FROM test_db.wp_term_relationships WHERE object_id= '" + wordpress_item_id + "';DELETE FROM test_db.wp_postmeta WHERE post_id= '" + wordpress_item_id + "'; DELETE FROM test_db.wp_posts WHERE ID = '" + wordpress_item_id + "'; ";
                                        MySqlConnection connection5 = new MySqlConnection(connectionString_dataload4);
                                        MySqlCommand data_command5 = new MySqlCommand(dataLoad_sql5, connection5);
                                        connection5.Open();
                                        data_command5.ExecuteNonQuery();
                                        connection5.Close();

                                        if (salePrice != 0m)
                                        {
                                            string mysql3 = "UPDATE test_db.wp_postmeta SET meta_value = '" + salePrice + "' WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_price'; UPDATE test_db.wp_postmeta SET meta_value = '" + salePrice + "' WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_sale_price'; ";
                                            MySqlConnection conn11 = new MySqlConnection(connectionString);
                                            MySqlCommand command11 = new MySqlCommand(mysql3, conn11);
                                            conn11.Open();
                                            command11.ExecuteNonQuery();
                                            conn11.Close();
                                            //MessageBox.Show(salePrice.ToString());
                                        }
                                        else
                                        {
                                            string mysql3 = "UPDATE test_db.wp_postmeta SET meta_value = '" + productPrice + "' WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_price'; DELETE from test_db.wp_postmeta WHERE post_id = '" + wordpress_item_id + "' and meta_key = '_sale_price';";
                                            MySqlConnection conn11 = new MySqlConnection(connectionString);
                                            MySqlCommand command11 = new MySqlCommand(mysql3, conn11);
                                            conn11.Open();
                                            command11.ExecuteNonQuery();
                                            conn11.Close();
                                           // MessageBox.Show(salePrice.ToString());
                                        }

                                        if (flag == 1)
                                        {
                                            int count = 1;
                                            foreach (string image in myimages)
                                            {
                                                string imageName = image.Replace(".jpg", "");
                                                string imageName1 = imageName.Replace(" ", "-");                                        
                                                                                              
                                                string mysql6 = "select id from test_db.wp_posts where post_type = 'attachment' and post_name = '" + imageName + "';";
                                                MySqlConnection conn9 = new MySqlConnection(connectionString);
                                                MySqlCommand command9 = new MySqlCommand(mysql6, conn9);
                                                conn9.Open();
                                                MySqlDataReader myreader4;
                                                myreader4 = command9.ExecuteReader();
                                                if (myreader4.Read())   //for empty
                                                {
                                                    int image_id1 = myreader4.GetInt32(0);
                                                    //MessageBox.Show(image_id1.ToString());                                                
                                                    string mysql7 = "DELETE FROM test_db.wp_posts Where id = '" + image_id1 + "'; DELETE FROM test_db.wp_postmeta Where meta_value = '" + image_id1 + "'; DELETE FROM test_db.wp_postmeta Where post_id = '" + image_id1 + "' ;";
                                                    MySqlConnection conn10 = new MySqlConnection(connectionString);
                                                    MySqlCommand command10= new MySqlCommand(mysql7, conn10);
                                                    conn10.Open();
                                                    command10.ExecuteNonQuery();
                                                    conn10.Close();
                                                }
                                                conn9.Close();
                                                string mysql5 = "INSERT INTO test_db.wp_posts (post_author, post_date, post_date_gmt, post_content,post_title, post_excerpt, post_status,comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt,post_content_filtered, post_parent , guid, menu_order, post_type, post_mime_type, comment_count) VALUES('" + wp_shop_id + "', '" + in_stock_date + "', '" + in_stock_date + "', '', '" + imageName + "','','inherit', 'open', 'closed','', '" + imageName1 + "','','', '" + in_stock_date + "','" + in_stock_date + "','' , '" + wordpress_item_id + "', 'http://localhost/mysite/wordpress/wp-content/uploads/2020/03/" + imageName1 + ".jpg','0', 'attachment','image/jpeg', '0') ;";
                                                MySqlConnection conn8 = new MySqlConnection(connectionString);
                                                MySqlCommand command8 = new MySqlCommand(mysql5, conn8);
                                                conn8.Open();
                                                command8.ExecuteNonQuery();
                                                conn8.Close();

                                                string mysql8 = "select id from test_db.wp_posts where post_type = 'attachment' and post_title = '" + imageName + "';";
                                                MySqlConnection conn12 = new MySqlConnection(connectionString);
                                                MySqlCommand command12 = new MySqlCommand(mysql8, conn12);
                                                conn12.Open();
                                                MySqlDataReader myreader3;
                                                myreader3 = command12.ExecuteReader();
                                                myreader3.Read();
                                                int image_id = myreader3.GetInt32(0);
                                                //MessageBox.Show(image_id.ToString());
                                                myreader3.Close();
                                                conn12.Close();
                                                if (count == 1)
                                                {
                                                    string mysql7 = "INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "', '_thumbnail_id', '" + image_id + "');INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attached_file','2020/03/" + imageName1 + ".jpg'); INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attachment_metadata','a:5:{s:5:\"width\";i:468;s:6:\"height\";i:801;s:4:\"file\";s:22:\"2020/03/" + imageName1 + ".jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-175x300.jpg\";s:5:\"width\";i:175;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:15:\"Siddhant Kandoi\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1583371749\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');";
                                                    MySqlConnection conn10 = new MySqlConnection(connectionString);
                                                    MySqlCommand command10 = new MySqlCommand(mysql7, conn10);
                                                    conn10.Open();
                                                    command10.ExecuteNonQuery();
                                                    conn10.Close();
                                                    count++;
                                                }
                                                else
                                                {
                                                    string mysql7 = "INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + wordpress_item_id + "','_product_image_gallery','" + image_id + "');INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attached_file','2020/03/" + imageName1 + ".jpg'); INSERT INTO test_db.wp_postmeta (post_id,meta_key,meta_value) VALUES('" + image_id + "','_wp_attachment_metadata','a:5:{s:5:\"width\";i:468;s:6:\"height\";i:801;s:4:\"file\";s:22:\"2020/03/" + imageName1 + ".jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-175x300.jpg\";s:5:\"width\";i:175;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-265x331.jpg\";s:5:\"width\";i:265;s:6:\"height\";i:331;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"" + imageName1 + "-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:15:\"Siddhant Kandoi\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1583371749\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');";
                                                    MySqlConnection conn10 = new MySqlConnection(connectionString);
                                                    MySqlCommand command10 = new MySqlCommand(mysql7, conn10);
                                                    conn10.Open();
                                                    command10.ExecuteNonQuery();
                                                    conn10.Close();
                                                }                                                
                                            }
                                        }
                                        //Code added by Shefali for Modify- End

                                        MessageBox.Show("Records have been modified", "Congratulations", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        this.Hide();

                                        //Declaring a variable for WelcomeForm
                                        WelcomeForm f2 = new WelcomeForm();

                                        //Showing WelcomeForm
                                        f2.ShowDialog();
                                    }
                                }

                                catch (Exception Ex)
                                    {
                                        MessageBox.Show("There is a problem with the database connection"+Ex, "Error occured", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        Console.WriteLine(Ex);
                                    }

                                }

                            }

                        
                    }
                }

            }




        }


        // -----------------------------------------------------------------------------------------------------------
        private void ImageListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
             //   MessageBox.Show(ImageListBox.SelectedIndex.ToString());

                if(ImageListBox.SelectedIndex != -1)
                {
                    ImagePictureBox.ImageLocation = imageList[ImageListBox.SelectedIndex];
                }
                
                /*
                 if(isUpload)
             {
                 if (ImageListBox.SelectedIndex != -1)
                 {
                     ImagePictureBox.ImageLocation = imageList[ImageListBox.SelectedIndex];
                 }


             }

             // Added by Gagan - Start
             else if (isModifyOrDelete)
             {
                 if (ImageListBox.SelectedIndex != -1)
                 {
                     ImagePictureBox.ImageLocation = @"C:\wamp64\www\mysite\wordpress\wp-content\uploads\2020\03\"+imageList[ImageListBox.SelectedIndex]+".jpg";
                 }
               }
             // Added by Gagan - End

             */
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong, Please contact admin with code IMG001"+ex,"ERROR", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                Console.WriteLine(ex);
            }

        }


        

        // ---------------------------------------------------------------------------------------------------------

        private void ProductNameTextBox_Enter(object sender, EventArgs e)
        {
            if (ProductNameTextBox.Text == "What are you selling?")
            {
                ProductNameTextBox.Text = "";
            }
        }
        private void ProductNameTextBox_Leave(object sender, EventArgs e)
        {
            if (ProductNameTextBox.Text == "")
            {
                ProductNameTextBox.Text = "What are you selling?";
            }
        }

       /*   private void ProductSizeRichTextBox_Enter(object sender, EventArgs e)
          {
              if (ProductSizeRichTextBox.Text == "if applicable?")
              {
                  ProductSizeRichTextBox.Text = "";
              }
          }
          private void ProductSizeRichTextBox_Leave(object sender, EventArgs e)
          {
              if (ProductSizeRichTextBox.Text == "")
              {
                  ProductSizeRichTextBox.Text = "if applicable?";
              }
          } */


        private void ProductDescriptionRichTextBox_Enter(object sender, EventArgs e)
        {
            if (ProductDescriptionRichTextBox.Text == "Describe what you are selling")
            {
                ProductDescriptionRichTextBox.Text = "";
            }
        }

        private void ProductDescriptionRichTextBox_Leave(object sender, EventArgs e)
        {
            if (ProductDescriptionRichTextBox.Text == "")
            {
                ProductDescriptionRichTextBox.Text = "Describe what you are selling";
            }
        }

        private void ProductPriceTextBox_Enter(object sender, EventArgs e)
        {
            if (ProductPriceTextBox.Text == "Product Price")
            {
                ProductPriceTextBox.Text = "";
            }
        }

        private void ProductPriceTextBox_Leave(object sender, EventArgs e)
        {
            if (ProductPriceTextBox.Text == "")
            {
                ProductPriceTextBox.Text = "Product Price";
            }
        }


        private void SalePriceTextBox_Enter(object sender, EventArgs e)
        {
            if (SalePriceTextBox.Text == "Sale Price")
            {
                SalePriceTextBox.Text = "";
            }
        }


        private void SalePriceTextBox_Leave(object sender, EventArgs e)
        {
            if (SalePriceTextBox.Text == "")
            {
                SalePriceTextBox.Text = "Sale Price";
            }
        }

       

        private void ProductSizeRichTextBox_Enter(object sender, EventArgs e)
        {
            if (ProductPriceTextBox.Text == "if applicable")
            {
                ProductSizeRichTextBox.Text = "";
            }
        }
      

        private void ProductSizeRichTextBox_Leave(object sender, EventArgs e)
        {
            if (ProductSizeRichTextBox.Text == "")
            {
                ProductSizeRichTextBox.Text = "if applicable";
            }
        }

        private void UploadForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (ImageListBox.SelectedIndex != -1)
            {

                if (ImageListBox.SelectedIndex != 0)
                {
                    string temp = imageList[ImageListBox.SelectedIndex];

                    imageList[ImageListBox.SelectedIndex] = imageList[ImageListBox.SelectedIndex - 1];
                    imageList[ImageListBox.SelectedIndex - 1] = temp;

                    ImageListBox.Items.Clear();
                    for (int i = 0; i < imageList.Count; i++)
                    {
                        if (i == 0)
                        {
                            ImageListBox.Items.Add(Path.GetFileName(imageList[i]) + " - Title Image");
                        }
                        else
                        {
                            ImageListBox.Items.Add(Path.GetFileName(imageList[i]));
                        }

                    }
                    ImageListBox.SelectedIndex = 0;

                }

                ImagePictureBox.ImageLocation = imageList[0];

            }
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            if (ImageListBox.SelectedIndex != -1)
            {
                if (ImageListBox.SelectedIndex != ImageListBox.Items.Count - 1)
                {
                    string temp = imageList[ImageListBox.SelectedIndex];

                    imageList[ImageListBox.SelectedIndex] = imageList[ImageListBox.SelectedIndex + 1];
                    imageList[ImageListBox.SelectedIndex + 1] = temp;


                    ImageListBox.Items.Clear();
                    for (int i = 0; i < imageList.Count; i++)
                    {
                        if (i == 0)
                        {
                            ImageListBox.Items.Add(Path.GetFileName(imageList[i]) + " - Title Image");
                        }
                        else
                        {
                            ImageListBox.Items.Add(Path.GetFileName(imageList[i]));
                        }
                    }
                    ImageListBox.SelectedIndex = 0;
                }
                ImagePictureBox.ImageLocation = imageList[0];
            }
        }
    }
    }
    
