﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace St_Vincent_De_Paul_Society
{
    public partial class ModifyScreen : Form
    {

        public HashSet<String> testc = new HashSet<string>();
        public Boolean isModify = false;
        public Boolean isDelete = false;

        public ModifyScreen()
        {
            InitializeComponent();
			FillComboBox();
        }


        public Boolean setIsModify
        {
            set
            {
                isModify = value;
            }
        }

        public Boolean setIsDelete
        {
            set
            {
                isDelete = value;
            }
        }

        // Code added for Database by Shefali- Start
        void FillComboBox()
        {
            try
            {
                // code to add items in categories Combobox
                string connectionString_dataload = "datasource=localhost;port=3308;username=root;password=";
                string dataLoad_sql = "select Concat(c.category_name, ' ' ,s.sub_category_name) as 'Categories'  from test_db.category c, test_db.sub_category s where c.CATEGORY_ID=s.CATEGORY_ID;";
                MySqlConnection connection = new MySqlConnection(connectionString_dataload);
                MySqlCommand data_command = new MySqlCommand(dataLoad_sql, connection);
                connection.Open();
                MySqlDataReader dataload;
                dataload = data_command.ExecuteReader();

                while (dataload.Read())
                {

                    string categories = dataload.GetString(0);
                    ProductCategoryComboBox.Items.Add(categories);
                }
                //ProductCategoryComboBox.Items.Add("Books");
                ///ProductCategoryComboBox.Items.Add("OTHER");
                connection.Close();

                // code to add items in Location Combobox
                string connectionString_dataload1 = "datasource=localhost;port=3308;username=root;password=";
                string dataLoad_sql1 = "SELECT shop_name FROM test_db.shop;";
                MySqlConnection connection1 = new MySqlConnection(connectionString_dataload1);
                MySqlCommand data_command1 = new MySqlCommand(dataLoad_sql1, connection1);
                connection1.Open();
                MySqlDataReader dataload1;
                dataload1 = data_command1.ExecuteReader();

                while (dataload1.Read())
                {

                    string shops = dataload1.GetString(0);
                    ProductLocationModifyFormComboBox.Items.Add(shops);
                }
                connection1.Close();
            }

            catch (Exception Ex)
            {
                MessageBox.Show("There is a problem with data Load", "Error occured", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Console.WriteLine(Ex);
            }
        }
        // Code added for Database by Shefali- End


        private void LogOutButton_Click(object sender, EventArgs e)
        {
            DialogResult resultLogout = MessageBox.Show("Do you wish to Log out??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (DialogResult.Yes == resultLogout)
            {
                this.Hide();

                //Declaring a variable for LoginForm
                LogInForm f1 = new LogInForm();

                //Showing WelcomeForm
                f1.ShowDialog();

            }

            else
            {


            }
        }

        private void ModifyButton_Click(object sender, EventArgs e)
        {
            if (ProductCategoryComboBox.SelectedIndex < 0)

            {
                MessageBox.Show("Please select a product category", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            else
            {
                if (ProductLocationModifyFormComboBox.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select the location", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);


                }
                else
                {
                    if (ProductDisplayDataGridView.SelectedRows.Count <= 0 && ProductDisplayDataGridView.SelectedCells.Count <= 0)
                    {
                        MessageBox.Show("Please choose a valid product from the list", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }

                    else
                    {
                        if (ProductDisplayDataGridView.SelectedRows.Count > 0)
                        {
                            
                            DataGridViewRow row = this.ProductDisplayDataGridView.SelectedRows[0];
                            //MessageBox.Show(row.Cells["ITEM_ID"].Value.ToString());
                            this.Hide();
                            //Declaring a variable for Modify form
                            UploadForm f3 = new UploadForm();
                            f3.productCategoryModifySet = ProductCategoryComboBox.SelectedIndex;
                            f3.productLocationLocationSet = ProductLocationModifyFormComboBox.SelectedIndex;
                            //f3.selectedProduct = ChooseProductsModifyScreenListBox.SelectedItem.ToString();
                           // MessageBox.Show(row.Cells["ITEM_ID"].Value.ToString());
                            f3.selectedProduct = row.Cells["ITEM_ID"].Value.ToString();         //Added by Shefali
                            f3.selectedProduct_Name = row.Cells["ITEM_NAME"].Value.ToString();  //Added by Shefali
                            f3.isModifyOrDeleteSet = true;
                            f3.isUploadSet = false;
                            //Showing WelcomeForm
                            f3.ShowDialog();

                            /*
                            this.Hide();
                            //Declaring a variable for Modify form
                            UploadForm f3 = new UploadForm();
                            f3.productCategoryModifySet = ProductCategoryComboBox.SelectedIndex;
                            f3.productLocationLocationSet = ProductLocationModifyFormComboBox.SelectedIndex;
                            f3.selectedProduct = ChooseProductsModifyScreenListBox.SelectedItem.ToString();
                            //Showing WelcomeForm
                            f3.ShowDialog();
                            */
                        }
                        else if (ProductDisplayDataGridView.SelectedCells.Count > 0 && ProductDisplayDataGridView.SelectedRows.Count == 0)
                        {
                            
                            int selectedrowindex = ProductDisplayDataGridView.SelectedCells[0].RowIndex;
                            DataGridViewRow row = this.ProductDisplayDataGridView.Rows[selectedrowindex];
                            
                            this.Hide();
                            //Declaring a variable for Modify form
                            UploadForm f3 = new UploadForm();
                            f3.productCategoryModifySet = ProductCategoryComboBox.SelectedIndex;
                            f3.productLocationLocationSet = ProductLocationModifyFormComboBox.SelectedIndex;
                            //f3.selectedProduct = ChooseProductsModifyScreenListBox.SelectedItem.ToString();
                            f3.selectedProduct = row.Cells["ITEM_ID"].Value.ToString();            //Added by Shefali
                            f3.selectedProduct_Name = row.Cells["ITEM_NAME"].Value.ToString();      //Added by Shefali
                            //Showing WelcomeForm
                            f3.isModifyOrDeleteSet = true;
                            f3.isUploadSet = false;
                            f3.ShowDialog();
                        }

                    }
                }


            }
        }

        private void ProductCategoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ProductCategoryComboBox.SelectedIndex != -1)
            {
                ProductLocationModifyFormComboBox.Enabled = true;
            }

            if (ProductCategoryComboBox.SelectedIndex != -1 && ProductLocationModifyFormComboBox.SelectedIndex != -1)
            {
                //testc.Clear();
                //ChooseProductsModifyScreenListBox.Items.Clear();
                //ChooseProductsModifyScreenListBox.Items.Add(ProductCategoryComboBox.SelectedItem + " " + ProductLocationModifyFormComboBox.SelectedItem);
                // ChooseProductsModifyScreenListBox.Items.Add("SELECT * FROM ITEMS WHERE PRODUCTCATEGORY = '" + ProductCategoryComboBox.SelectedItem + "' AND PRODUCTLOCATIO = " +ProductLocationModifyFormComboBox.SelectedItem + "'" );


                /*string connectionString_dataload3 = "datasource=localhost;port=3308;username=root;password=";
                string dataLoad_sql3 = "select ITEM_ID, ITEM_NAME, PRIZE, SIZE from test_db.inventory where shop_id = '" + db_shop_id + "' and sub_category_id = '" + db_category_id + "';";
                MySqlConnection connection3 = new MySqlConnection(connectionString_dataload3);
                MySqlCommand data_command3 = new MySqlCommand(dataLoad_sql3, connection3);
                connection3.Open();
                MySqlDataAdapter dtb = new MySqlDataAdapter(data_command3);
                DataTable dt = new DataTable();
                dtb.Fill(dt);
                DisplayProductDataGridView.DataSource = dt;
                //dtb.Close();
                connection3.Close();
                dtb.Dispose();*/
                ProductDisplayDataGridView.DataSource = null;
                displayDataInDataGridView();


            }

        }



        /*   private void ProductCategoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
           {
               if (ProductCategoryComboBox.SelectedIndex != -1)
               {
                   testc.Clear();
                   ChooseProductsModifyScreenListBox.Items.Clear();

                   ProductLocationModifyFormComboBox.Enabled = true;
                   //ChooseProductsModifyScreenListBox.Items.Add(ProductCategoryComboBox.SelectedItem + " " + ProductLocationModifyFormComboBox.SelectedItem);

                   foreach (String item in ChooseProductsModifyScreenListBox.Items)
                   {
                       testc.Add(item);
                   }
                   //ChooseProductsModifyScreenListBox.Items.Add("SELECT * FROM ITEMS WHERE PRODUCTCATEGORY = '" + ProductCategoryComboBox.SelectedItem + "'");
               }
           } */

        /*  private void ProductLocationModifyFormComboBox_SelectedIndexChanged(object sender, EventArgs e)
          {
              if (ProductCategoryComboBox.SelectedIndex != -1 && ProductLocationModifyFormComboBox.SelectedIndex != -1)
              {
                 // testc.Clear();
                 // ChooseProductsModifyScreenListBox.Items.Clear();
                  //ChooseProductsModifyScreenListBox.Items.Add(ProductCategoryComboBox.SelectedItem + " " + ProductLocationModifyFormComboBox.SelectedItem);
                  // ChooseProductsModifyScreenListBox.Items.Add("SELECT * FROM ITEMS WHERE PRODUCTCATEGORY = '" + ProductCategoryComboBox.SelectedItem + "' AND PRODUCTLOCATIO = " +ProductLocationModifyFormComboBox.SelectedItem + "'" );
                  try
                  {
                      string product_type = ProductCategoryComboBox.SelectedItem.ToString();
                      string shop_location = ProductLocationModifyFormComboBox.SelectedItem.ToString();
                      string trimmed_productType = product_type.Replace("Collectable ", "").Replace("Accessories ", "").Replace("Living ", "").Replace("Clothing ", "").Replace("Hobbies ", "").Replace("Expensive ", "");
                      string trimmed_productLocation = shop_location.Replace("Merchant's", "").Replace("Vincent's", "");
                      //string in_stock_date = DateTime.Now.ToString("yyyy-MM-dd");
                      string connectionString = "datasource=localhost;port=3308;username=root;password=";
                      string sql = "SELECT SUB_CATEGORY_ID FROM test_db.SUB_CATEGORY WHERE SUB_CATEGORY_NAME LIKE '%" + trimmed_productType + "%';";
                      string sql1 = "SELECT SHOP_ID FROM test_db.SHOP WHERE SHOP_NAME LIKE '%" + trimmed_productLocation + "%';";

                      //Code for database connection for select statements.
                      MySqlConnection conn = new MySqlConnection(connectionString);
                      MySqlConnection conn1 = new MySqlConnection(connectionString);
                      MySqlCommand command = new MySqlCommand(sql, conn);
                      MySqlCommand command1 = new MySqlCommand(sql1, conn1);
                      conn.Open();
                      conn1.Open();
                      MySqlDataReader myreader, mydata;
                      myreader = command.ExecuteReader();
                      mydata = command1.ExecuteReader();
                      myreader.Read();
                      mydata.Read();
                      int db_category_id = myreader.GetInt32(0);
                      //MessageBox.Show(db_category_id.ToString());
                      int db_shop_id = mydata.GetInt32(0);
                      //MessageBox.Show(db_shop_id.ToString());
                      myreader.Close();
                      mydata.Close();
                      conn.Close();
                      conn1.Close();

                      string connectionString_dataload2 = "datasource=localhost;port=3308;username=root;password=";
                      //string dataLoad_sql2 = "select ITEM_ID, ITEM_NAME, PRIZE, SIZE from test_db.inventory where shop_id = '"+ db_category_id + "' and sub_category_id = '" + db_shop_id + "';";
                      string dataLoad_sql2 = "select ITEM_ID, ITEM_NAME, PRIZE, SALE, SIZE from test_db.inventory where shop_id = '"+ db_shop_id + "' and sub_category_id = '" + db_category_id + "';"; 
                      MySqlConnection connection2 = new MySqlConnection(connectionString_dataload2);
                      MySqlCommand data_command2 = new MySqlCommand(dataLoad_sql2, connection2);
                      connection2.Open();
                      MySqlDataReader dataload2;
                      dataload2 = data_command2.ExecuteReader();
                      //string display_products = String.Format("{0,10} {1,20} {2,10} {3,10} {4,10}","Item ID","Item Name","Price","Sale","Size");
                      string display_products = "Item ID" + "" + "Item Name" + "   " + "Price"  + "   " + "Sale" + "   " + "Size";
                      ChooseProductsModifyScreenListBox.Items.Add(display_products);

                      while (dataload2.Read())
                      {
                          string item_id = dataload2.GetString(0);
                          string item_name = dataload2.GetString(1);
                          string prize = dataload2.GetString(2);
                          string sale = dataload2.GetString(3);
                          string size = dataload2.GetString(4);
                          //string display_products1 = String.Format("{0,15} {1,15} {2,10} {3,10} {4,10}",item_id,item_name,prize,sale,size);
                          string display_products1 = item_id + "" + item_name + "   " + prize + "  	" +  sale  + "   " + size;
                          ChooseProductsModifyScreenListBox.Items.Add(display_products1);
                      }
                      connection2.Close();
                  }

                  catch (Exception Ex)
                  {
                      MessageBox.Show("There is a problem with data Load", "Error occured", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                      Console.WriteLine(Ex);
                  }


              } 


              foreach (String item in ChooseProductsModifyScreenListBox.Items)
              {
                  testc.Add(item);
              }


          }

          

          private void SearchTextBox_TextChanged(object sender, EventArgs e)
          {


              string SEARCHSTRING = SearchTextBox.Text;

              if (!String.IsNullOrEmpty(SEARCHSTRING))
              {
                  ChooseProductsModifyScreenListBox.Items.Clear();
                  foreach (String item in testc)
                  {
                      //string listString = testc[i].ToString();
                      if (item.ToLower().Contains(SEARCHSTRING.ToLower()))
                      {
                          ChooseProductsModifyScreenListBox.Items.Add(item);

                      }
                  }
              }
              else
              {
                  ChooseProductsModifyScreenListBox.Items.Clear();
                  foreach (String item in testc)
                  {
                      ChooseProductsModifyScreenListBox.Items.Add(item);
                  }
              }


          }*/


        private void ProductLocationModifyFormComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            if (ProductCategoryComboBox.SelectedIndex != -1 && ProductLocationModifyFormComboBox.SelectedIndex != -1)
            {
                //testc.Clear();
                //ProductDisplayDataGridView.Items.Clear();
                //ChooseProductsModifyScreenListBox.Items.Add(ProductCategoryComboBox.SelectedItem + " " + ProductLocationModifyFormComboBox.SelectedItem);
                // ChooseProductsModifyScreenListBox.Items.Add("SELECT * FROM ITEMS WHERE PRODUCTCATEGORY = '" + ProductCategoryComboBox.SelectedItem + "' AND PRODUCTLOCATIO = " +ProductLocationModifyFormComboBox.SelectedItem + "'" );
                ProductDisplayDataGridView.DataSource = null;
                displayDataInDataGridView();


            }

        }

     /*   private void SearchTextBox_Enter(object sender, EventArgs e)
        {
            SearchTextBox.Text = "";
        }

        private void SearchTextBox_Leave(object sender, EventArgs e)
        {
            if (SearchTextBox.Text == "")
            {
                SearchTextBox.Text = "Type anything to search";
            }
        } */

        private void BackButton_Click(object sender, EventArgs e)
        {
            DialogResult resultBack = MessageBox.Show("Do you wish to go back??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (DialogResult.Yes == resultBack)
            {
                this.Hide();

                //Declarrng a variable for WelcomeForm
                WelcomeForm f2 = new WelcomeForm();

                //Showing WelcomeForm
                f2.ShowDialog();

            }

            else
            {


            }
        }

        private void displayDataInDataGridView()
        {
            try
            {
                // Code added for Database by Shefali- Start
                string product_type = ProductCategoryComboBox.SelectedItem.ToString();
                string[] categories = product_type.Split();
                string shop_location = ProductLocationModifyFormComboBox.SelectedItem.ToString();
                string trimmed_productLocation = shop_location.Replace("Merchant's", "").Replace("Vincent's", "");
                string sql1 = "SELECT SHOP_ID FROM test_db.SHOP WHERE SHOP_NAME LIKE '%" + trimmed_productLocation + "%';";
                string in_stock_date = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
                string connectionString = "datasource=localhost;port=3308;username=root;password=;character set = utf8";
                int category_id = 0;
                string str1 = categories[0];
                string str2 = categories[1];
                String sql0 = "SELECT CATEGORY_ID FROM test_db.CATEGORY WHERE CATEGORY_NAME LIKE '%" + str1 + "%';";
                MySqlConnection conn0 = new MySqlConnection(connectionString);
                MySqlCommand command0 = new MySqlCommand(sql0, conn0);
                conn0.Open();
                MySqlDataReader myreader0;
                myreader0 = command0.ExecuteReader();
                myreader0.Read();
                category_id = myreader0.GetInt32(0);
                myreader0.Close();
                conn0.Close();
                string sql = "SELECT SUB_CATEGORY_ID FROM test_db.SUB_CATEGORY WHERE SUB_CATEGORY_NAME LIKE '%" + str2 + "%' and CATEGORY_ID = '" + category_id + "';";

                //Code for database connection for select statements.
                MySqlConnection conn = new MySqlConnection(connectionString);
                MySqlConnection conn1 = new MySqlConnection(connectionString);
                MySqlCommand command = new MySqlCommand(sql, conn);
                MySqlCommand command1 = new MySqlCommand(sql1, conn1);
                conn.Open();
                conn1.Open();
                MySqlDataReader myreader, mydata;
                myreader = command.ExecuteReader();
                mydata = command1.ExecuteReader();
                myreader.Read();
                mydata.Read();
                int db_category_id = myreader.GetInt32(0);
                int db_shop_id = mydata.GetInt32(0);
                myreader.Close();
                mydata.Close();
                conn.Close();
                conn1.Close();

                string connectionString_dataload2 = "datasource=localhost;port=3308;username=root;password=";
                string dataLoad_sql2 = "select ITEM_ID, ITEM_NAME, PRIZE, SIZE from test_db.inventory where shop_id = '" + db_shop_id + "' and sub_category_id = '" + db_category_id + "';";
                MySqlConnection connection2 = new MySqlConnection(connectionString_dataload2);
                MySqlCommand data_command2 = new MySqlCommand(dataLoad_sql2, connection2);
                connection2.Open();
                MySqlDataAdapter dtb = new MySqlDataAdapter(data_command2);
                
                DataTable dt = new DataTable();
                dtb.Fill(dt);
                // Code added for Database by Shefali- End

                if (dt.Rows.Count > 0)
                {
                    ProductDisplayDataGridView.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No Data found for the category, Please select another category to Proceed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ProductCategoryComboBox.Focus();
                    ModifyButton.Enabled = false;
                    DeleteButton.Enabled = false;
                    
                }

                
                
                connection2.Close();
                dtb.Dispose();

                

                
            
            }

            catch (Exception Ex)
            {
                MessageBox.Show("There is a problem with data Load", "Error occured", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Console.WriteLine(Ex);
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {

                if (ProductDisplayDataGridView.SelectedRows.Count > 0)
                {
                        DataGridViewRow row = ProductDisplayDataGridView.SelectedRows[0];       //Added by Shefali
                        int item_id = int.Parse(row.Cells["ITEM_ID"].Value.ToString());         //Added by Shefali
                        string item_name = row.Cells["ITEM_NAME"].Value.ToString();             //Added by Shefali
                        //MessageBox.Show(item_name);
                        string connectionString_dataload4 = "datasource=localhost;port=3308;username=root;password=";

                        DialogResult deleteConfirmation = MessageBox.Show("Are you sure you want to delete the Item with Item Name - " + item_name + " and Item Id - " + item_id + " ?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


                    if (deleteConfirmation == DialogResult.Yes)
                    {
                        // Code added for Database by Shefali- Start
                        //Svp query for deletion.
                        string dataLoad_sql4 = "DELETE FROM test_db.inventory WHERE ITEM_ID = '" + item_id + "';";
                        MySqlConnection connection4 = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand data_command4 = new MySqlCommand(dataLoad_sql4, connection4);
                        connection4.Open();
                        data_command4.ExecuteNonQuery();
                        connection4.Close();

                        //wordpress query for deletion.

                        string sql = "select id from test_db.wp_posts where post_type = 'product' and post_title = '" + item_name + "';";
                        MySqlConnection conn = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand command = new MySqlCommand(sql, conn);
                        conn.Open();
                        MySqlDataReader myreader;
                        myreader = command.ExecuteReader();
                        myreader.Read();
                        int wordpress_item_id = myreader.GetInt32(0);
                        //MessageBox.Show(wordpress_item_id.ToString());
                        myreader.Close();
                        conn.Close();


                        string dataLoad_sql5 = "DELETE FROM test_db.wp_term_relationships WHERE object_id= '" + wordpress_item_id + "';DELETE FROM test_db.wp_postmeta WHERE post_id= '" + wordpress_item_id + "'; DELETE FROM test_db.wp_posts WHERE ID = '" + wordpress_item_id + "'; DELETE FROM test_db.wp_postmeta WHERE post_id= '" + wordpress_item_id + "'; DELETE FROM test_db.wp_posts WHERE post_parent = '" + wordpress_item_id + "'; ";
                        MySqlConnection connection5 = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand data_command5 = new MySqlCommand(dataLoad_sql5, connection5);
                        connection5.Open();
                        data_command5.ExecuteNonQuery();
                        connection5.Close();
                        // Code added for Database by Shefali- End

                        //Print message 
                        MessageBox.Show("Records has been deleted.", "Congratulations!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        if (ProductDisplayDataGridView.Rows.Count == 1)
                        {
                            ProductCategoryComboBox.SelectedIndex = -1;
                            ProductLocationModifyFormComboBox.SelectedIndex = -1;
                            ProductDisplayDataGridView.DataSource = null;
                            ProductLocationModifyFormComboBox.Enabled = false;
                        }
                        else
                        {
                            ProductDisplayDataGridView.DataSource = null;
                            displayDataInDataGridView();
                        }
                    }

                       
                    
            }
            else if(ProductDisplayDataGridView.SelectedCells.Count > 0 && ProductDisplayDataGridView.SelectedRows.Count == 0)
            {
                    int selectedrowindex = ProductDisplayDataGridView.SelectedCells[0].RowIndex;
                    DataGridViewRow row = this.ProductDisplayDataGridView.Rows[selectedrowindex];
                    int item_id = int.Parse(row.Cells["ITEM_ID"].Value.ToString());                 //Added by Shefali
                    string item_name = row.Cells["ITEM_NAME"].Value.ToString();                     //Added by Shefali
                    //MessageBox.Show(item_name);
                    string connectionString_dataload4 = "datasource=localhost;port=3308;username=root;password=";


                    DialogResult deleteConfirmation = MessageBox.Show("Are you sure you want to delete the Item with Item Name - " + item_name + " and Item Id - " + item_id + " ?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


                    if(deleteConfirmation == DialogResult.Yes) {
                        // Code added for Database by Shefali- Start
                        //Svp query for deletion.
                        string dataLoad_sql4 = "DELETE FROM test_db.inventory WHERE ITEM_ID = '" + item_id + "';";
                        MySqlConnection connection4 = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand data_command4 = new MySqlCommand(dataLoad_sql4, connection4);
                        connection4.Open();
                        data_command4.ExecuteNonQuery();
                        connection4.Close();

                        //wordpress query for deletion.
                        string sql = "select id from test_db.wp_posts where post_type = 'product' and post_title = '" + item_name + "';";
                        MySqlConnection conn = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand command = new MySqlCommand(sql, conn);
                        conn.Open();
                        MySqlDataReader myreader;
                        myreader = command.ExecuteReader();
                        myreader.Read();
                        int wordpress_item_id = myreader.GetInt32(0);
                        //MessageBox.Show(wordpress_item_id.ToString());
                        myreader.Close();
                        conn.Close();
                        
                        string dataLoad_sql5 = "DELETE FROM test_db.wp_term_relationships WHERE object_id= '" + wordpress_item_id + "';DELETE FROM test_db.wp_postmeta WHERE post_id= '" + wordpress_item_id + "'; DELETE FROM test_db.wp_posts WHERE ID = '" + wordpress_item_id + "'; ";
                        MySqlConnection connection5 = new MySqlConnection(connectionString_dataload4);
                        MySqlCommand data_command5 = new MySqlCommand(dataLoad_sql5, connection5);
                        connection5.Open();
                        data_command5.ExecuteNonQuery();
                        connection5.Close();
                        // Code added for Database by Shefali- Start

                        //Print message 
                        MessageBox.Show("Records has been deleted.", "Congratulations!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        if (ProductDisplayDataGridView.Rows.Count == 1)
                        {
                            ProductCategoryComboBox.SelectedIndex = -1;
                            ProductLocationModifyFormComboBox.SelectedIndex = -1;
                            ProductDisplayDataGridView.DataSource = null;
                            ProductLocationModifyFormComboBox.Enabled = false;
                        }
                        else
                        {
                            ProductDisplayDataGridView.DataSource = null;
                            displayDataInDataGridView();
                        }
                    }

                }

                else
                {
                MessageBox.Show("Please select a product to delete", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
        
            }
                catch (Exception Ex)
            {
                MessageBox.Show("There is a problem with record Retrive." + Ex, "Error occured!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Console.WriteLine(Ex);
            }
        }

        private void ModifyScreen_Load(object sender, EventArgs e)
        {
            if(isDelete == true)
            {
                ModifyButton.Visible = false;
                DeleteButton.Visible = true;
            }

            if (isModify == true)
            {
                ModifyButton.Visible = true;
                DeleteButton.Visible = false;
            }
        }

        private void ProductDisplayDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            ModifyButton.Enabled = true;
            DeleteButton.Enabled = true;
        }

        private void ProductDisplayDataGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {

        }

        private void ModifyScreen_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }

}
    

